// ignore_for_file: use_key_in_widget_constructors, prefer_const_constructors, unnecessary_new

import 'package:flutter/material.dart';

class SkillsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(


      body: Center(
        child: SafeArea(
          child: Column(
            children: [
              Image(image: AssetImage('images/IMG_20231002_101853.jpg')),
              SizedBox(height: 20,),
              Text(" Mchine Learning\n App Development\n Video Editing\n Image Editing ",style: TextStyle(fontSize:18),)
          ],

          ),
        ),
      ),

    );
  }
}
